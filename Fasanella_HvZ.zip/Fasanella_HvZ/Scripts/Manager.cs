﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//Kyle Fasanella
//for managing the scene - spawning, keeping in a list

public class Manager : MonoBehaviour {

    public GameObject humanPre;
    public GameObject zombiePre;
    public GameObject obstacle;
    public List<GameObject> humans;
    public List<GameObject> obstacles;
    public List<GameObject> zombies;
    public float spawnRange;
    public float zombieNum;
    public float humanNum;
    public float obstacleNum;

    // Use this for initialization
    void Start () {
        //create humans, zombies, obstacles
        humans = new List<GameObject>();
        zombies = new List<GameObject>();
        obstacles = new List<GameObject>();

        for (int i = 0; i < humanNum; i++)
        {
            GameObject guy = Instantiate(humanPre, new Vector3(Random.Range(-spawnRange, spawnRange), 0, Random.Range(-spawnRange, spawnRange)), Quaternion.identity);
            humans.Add(guy);
        }
        for (int i = 0; i < zombieNum; i++)
        {
            GameObject zomb = Instantiate(zombiePre, new Vector3(Random.Range(-spawnRange, spawnRange), 0, Random.Range(-spawnRange, spawnRange)), Quaternion.identity);
            zombies.Add(zomb);
        }
        for (int i = 0; i < obstacleNum; i++)
        {
            GameObject obst = Instantiate(obstacle, new Vector3(Random.Range(-spawnRange, spawnRange), 0, Random.Range(-spawnRange, spawnRange)), Quaternion.Euler(-90,0,Random.Range(-180,180)));
            obstacles.Add(obst);
        }
    }
	
	// Update is called once per frame
	void Update () {
		
	}
}
