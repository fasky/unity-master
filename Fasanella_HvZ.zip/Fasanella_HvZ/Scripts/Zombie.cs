﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//Kyle Fasanella
//for zombies - pursue humans

public class Zombie : Vehicle {

    // Use this for initialization
    void Start () {
        vehiclePosition = transform.position;
        manager = GameObject.Find("Manager").GetComponent<Manager>();
        radius = GetComponent<BoxCollider>().size.x;
        tempList = new List<GameObject>();
        timePassed = 30;
        lines = false;
        lines = manager.zombies[0].GetComponent<Zombie>().lines;
        center = GameObject.Find("Bounder");
	}
	
	// Update is called once per frame
	void Update () {
        //for seperation
        tempList = manager.zombies;

        if (Input.GetKeyDown(KeyCode.D))
        {
            lines = !lines;
        }

        timePassed++;

        //grab transoform pos
        vehiclePosition = transform.position;
        Bounce();

        //check for closest human and chase
        CheckHumans();

        //check collision with human
        CollisionHuman();

        acceleration = CalcSteeringForces();

        //add acceleration to velocity
        velocity += acceleration * Time.deltaTime;

        //normlaize direction
        direction = velocity.normalized;

        //add velocity to position
        vehiclePosition += velocity * Time.deltaTime;

        //draw if maxSpeed is >0
        if (maxSpeed > 0)
        {
            transform.position = vehiclePosition;
        }

        Rotate();
        //reset acceleration
        acceleration = Vector3.zero;
    }

    //calc steering forces
    public override Vector3 CalcSteeringForces()
    {
        steeringForce = Vector3.zero;
        if (outside)
        {
            steeringForce += Seek(center.transform.position);
        }
        else
        {
            //if the method is called, a human is in range, so seek
            if (closest)
            {
                steeringForce += Pursue(closest.transform.position);
            }
            else
            {
                steeringForce += Wander() * 2;
            }
            steeringForce += ObstacleAvoidance() * 8;
            steeringForce += Seperation() * 4;
        }
        return Vector3.ClampMagnitude(steeringForce, maxForce);
    }

    //debug lines
    void OnRenderObject()
    {
        if (lines)
        {
            //to target
            mat1.SetPass(0);
            GL.Begin(GL.LINES);
            GL.Vertex(transform.position);
            if (closest)
            {
                GL.Vertex(closest.transform.position + new Vector3(closest.GetComponent<Human>().velocity.normalized.x * 2, 0, closest.GetComponent<Human>().velocity.normalized.z * 2));
            }
            GL.End();

            //forward
            mat2.SetPass(0);
            GL.Begin(GL.LINES);
            GL.Vertex(transform.position);
            GL.Vertex(transform.position + new Vector3(velocity.normalized.x, 0, velocity.normalized.z));
            GL.End();

            //right
            mat3.SetPass(0);
            GL.Begin(GL.LINES);
            GL.Vertex(transform.position);
            GL.Vertex(transform.position + (Quaternion.Euler(0, 90, 0) * new Vector3(velocity.normalized.x, 0, velocity.normalized.z)));
            GL.End();

            //future
            mat4.SetPass(0);
            GL.Begin(GL.LINES);
            Vector3 pos = transform.position + new Vector3(velocity.normalized.x * 2, 0, velocity.normalized.z * 2);
            drawRad = .1f;
            for (int i = 0; i < 360; i++)
            {
                float degInRad = i * (Mathf.PI / 180);
                GL.Vertex(pos);
                GL.Vertex(new Vector3(pos.x + Mathf.Cos(degInRad) * drawRad, pos.y, pos.z + Mathf.Sin(degInRad) * drawRad));
            }
            GL.End();
        }
    }

}
