﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//Kyle Fasanella
//for handling cameras switching, and the GUI

public class Cameras : MonoBehaviour
{

    public GameObject human;
    public Camera[] cameras;
    public int currentCamIndex;

    // Use this for initialization
    void Start()
    {
        //start in fps
        currentCamIndex = 1;

        for (int i = 1; i < cameras.Length; i++)
        {
            cameras[i].gameObject.SetActive(false);
        }

        if (cameras.Length > 0)
        {
            cameras[0].gameObject.SetActive(true);
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            if(currentCamIndex == 4)
            {
                GameObject hum = Instantiate(human, new Vector3(GameObject.Find("Player").transform.position.x, 0, GameObject.Find("Player").transform.position.z), Quaternion.identity);
                GameObject.Find("Manager").GetComponent<Manager>().humans.Add(hum);
            }
        }

        //if c is pressed, cycle through the camera index, check if valid index, set active camera accordingly and adjust cam index if needed.
        if (Input.GetKeyDown(KeyCode.C))
        {
            currentCamIndex++;
        }

        if (currentCamIndex < cameras.Length)
        {
            cameras[currentCamIndex - 1].gameObject.SetActive(false);
            cameras[currentCamIndex].gameObject.SetActive(true);
        }

        else
        {
            cameras[currentCamIndex - 1].gameObject.SetActive(false);
            currentCamIndex = 0;
            cameras[currentCamIndex].gameObject.SetActive(true);
        }
    }

    //draw the gui, give info based on camera in use
    void OnGUI()
    {
        string current;
        switch (currentCamIndex)
        {
            case 0:
                current = "Angled View";
                break;
            case 1:
                current = "Main View";
                break;
            case 2:
                current = "Side View";
                break;
            case 3:
                current = "Top View";
                break;
            case 4:
                current = "FPS View";
                break;
            default:
                current = "Nothing";
                break;
        }

        GUI.Box(new Rect(10, 10, 250, 72), "Press 'c' to change camera\nCurrent: " + current + "\nClick in FPS cam to place a human\nPress 'd' to toggle debug lines");

    }
}

