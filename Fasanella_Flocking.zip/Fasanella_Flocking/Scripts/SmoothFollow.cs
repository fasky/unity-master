﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//Kyle Fasanella
//class for a smooth camera follow

public class SmoothFollow : MonoBehaviour {

    public Transform target;
    public float distance = 3;
    public float height = 1.5f;
    public float heightDamping = 2.0f;
    public float positionDamping = 2.0f;
    public float rotationDamping = 2.0f;
    public bool forward = false;
	// Use this for initialization
	void LateUpdate()
    {
        if (!target) return;

        float wantedHeight = target.position.y + height;
        float currentHeight = transform.position.y;

        //damp height
        currentHeight = Mathf.Lerp(currentHeight, wantedHeight, heightDamping * Time.deltaTime);

        if (forward)
        {
            //set positon of cam
            Vector3 wantedPosition = target.position + target.forward * distance;
            transform.position = Vector3.Lerp(transform.position, wantedPosition, Time.deltaTime * positionDamping);
        }
        else
        {
            //set positon of cam
            Vector3 wantedPosition = target.position - target.forward * distance;
            transform.position = Vector3.Lerp(transform.position, wantedPosition, Time.deltaTime * positionDamping);
        }


        //adjust height
        transform.position = new Vector3(transform.position.x, currentHeight, transform.position.z);

        if (forward)
        {
            //set forward rotate with time
            transform.forward = Vector3.Lerp(transform.forward, target.forward * -1, Time.deltaTime * rotationDamping);
        }
        else
        {
            //set forward rotate with time
            transform.forward = Vector3.Lerp(transform.forward, target.forward, Time.deltaTime * rotationDamping);
        }

    }
}
