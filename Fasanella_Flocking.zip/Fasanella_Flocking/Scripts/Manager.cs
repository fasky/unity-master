﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//Kyle Fasanella
//for managing the scene - spawning, keeping in a list

public class Manager : MonoBehaviour {

    public GameObject flockerPre;
    public GameObject obstacle;
    public List<GameObject> flockers;
    public List<GameObject> obstacles;
    public float spawnRange;
    public float flockersNum;
    public float obstacleNum;
    public Vector3 flockVelocity;
    public Vector3 flockPos;
    public Material mat2;
    public Terrain terrain;

    // Use this for initialization
    void Start () {
        //create humans, zombies, obstacles
        flockers = new List<GameObject>();
        obstacles = new List<GameObject>();

        for (int i = 0; i < flockersNum; i++)
        {
            GameObject guy = Instantiate(flockerPre, new Vector3(Random.Range(-spawnRange, spawnRange), 0.5f, Random.Range(-spawnRange, spawnRange)), Quaternion.identity);
            flockers.Add(guy);
        }
        for (int i = 0; i < obstacleNum; i++)
        {
            GameObject obst = Instantiate(obstacle, new Vector3(Random.Range(-spawnRange, spawnRange), 2.5f, Random.Range(-spawnRange, spawnRange)), Quaternion.Euler(-90,Random.Range(-180,180),0));
            obst.transform.position = new Vector3(obst.transform.position.x, terrain.SampleHeight(obst.transform.position), obst.transform.position.z);
            obstacles.Add(obst);
        }
    }
	
	// Update is called once per frame
	void Update () {

        flockVelocity = Vector3.zero;
        flockPos = Vector3.zero;

		foreach(GameObject flockee in flockers)
        {
            flockVelocity += flockee.GetComponent<Flocker>().velocity;
            flockPos += flockee.GetComponent<Flocker>().vehiclePosition;
        }

        flockPos = (flockPos / flockers.Count);

        GameObject.Find("AveragePos").transform.LookAt(flockVelocity);

        GameObject.Find("AveragePos").transform.position = flockPos;
	}

    //debug lines
    void OnRenderObject()
    {
        //vector
        mat2.SetPass(0);
        GL.Begin(GL.LINES);
        GL.Vertex(GameObject.Find("AveragePos").transform.position);
        GL.Vertex(GameObject.Find("AveragePos").transform.position + flockVelocity.normalized*4);
        GL.End();
    }
}
